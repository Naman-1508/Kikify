import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:kikify/widgets/sneaker_card.dart';
import 'package:kikify/widgets/category_chip.dart';
import 'package:kikify/models/sneaker.dart';

class HomePage extends StatefulWidget {
  final bool isDarkMode;
  final VoidCallback onToggleTheme;
  const HomePage({Key?key,required this.isDarkMode,required this.onToggleTheme}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage>{
  bool isDarkMode = false;
  final List<String> categories = ['Hype' , 'Rare' , 'Under Retail'];
  String selectedCategory = 'Hype';

  @override
  Widget build(BuildContext context) {
    final isDarkMode = widget.isDarkMode;
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: isDarkMode ? Color(0xFFF0FFF4) : Color(0xFF81C784),
      appBar: AppBar(
      backgroundColor: Colors.white.withOpacity(0.05),
        elevation: 0,
        title: const Text('KIKIFY',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold,fontSize: 24,
            shadows: [Shadow(color: Colors.black54,blurRadius: 10)],
            letterSpacing: 2,),),
        centerTitle: true,
        actions: [
          IconButton(
              icon: Icon(isDarkMode ? Icons.light_mode : Icons.dark_mode),
          onPressed: widget.onToggleTheme,
          ),
          const SizedBox(height: 10,),
        ],
        leading: Padding(
          padding: const EdgeInsets.all(8.0),
          child: CircleAvatar(
            backgroundImage: NetworkImage('https://i.pravatar.cc/150?img=3',),
          ),
        ),
        flexibleSpace: ClipRect(
          child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10,sigmaY: 10),
            child: Container(
              color: Colors.transparent ,
            ),
          ),
        ),
      ),
      bottomNavigationBar: ClipRRect(
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(30),
          topRight: Radius.circular(30),
        ),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10,sigmaY: 10),
          child: BottomNavigationBar(
            backgroundColor:
            isDarkMode ? Colors.grey[900]!.withOpacity(0.7) : Colors.white.withOpacity(0.7),
            type: BottomNavigationBarType.fixed,
            selectedItemColor: Colors.black,
            unselectedItemColor: isDarkMode ? Colors.white60 : Colors.black54,
            items: const[
              BottomNavigationBarItem(icon: Icon(Icons.home),label: 'Home'),
              BottomNavigationBarItem(icon: Icon(Icons.favorite),label: 'Wishlist'),
              BottomNavigationBarItem(icon: Icon(Icons.explore),label: 'Explore'),
              BottomNavigationBarItem(icon: Icon(Icons.person),label: 'Profile'),
            ],
          ),
        ),
      ),

      body: Padding(padding: const EdgeInsets.fromLTRB(20,100,20,0),
      child: ListView(
          children: [
            Text(
              'Welcome back, Sneakerhead 👋',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 20,),
            const Text('Find YOUR\nNEXT GRAIL',
            style: TextStyle(fontSize: 28,fontWeight: FontWeight.bold)),
            const SizedBox(height: 20,),
            TextField(
              decoration: InputDecoration(
                hintText: 'Search sneakers...',
                filled: true,
                fillColor: isDarkMode ? Colors.grey[800] : Colors.white,
                prefixIcon: const Icon(Icons.search),
                suffixIcon: const Icon(Icons.mic),
                contentPadding: const EdgeInsets.symmetric(horizontal: 20),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide.none,
                )
              ),
            ),
            const SizedBox(height: 20,),
            SizedBox(
              height: 40,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: categories.length,
                itemBuilder: (context,index){
                  final cat = categories[index];
                  return CategoryChip(label: cat, isSelected: selectedCategory == cat,
                      onTap:(){
                    setState(() {
                      selectedCategory=cat;
                    });
                      });
                },
              ),
            ),
            const SizedBox(height: 20,),
            const Text(
              '🔥 Featured',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),

            SizedBox(
              height: 240,
              child: PageView.builder(
                  itemCount: dummySneakers.length,
                  controller: PageController(viewportFraction: 0.75),
                  itemBuilder: (context,index){
                    return Transform.scale(
                      scale: 1,
                      child: SneakerCard(sneaker: dummySneakers[index]),
                    );
                  },),
            ),
            const SizedBox(height: 30,),
            const Text(
              '🛎 Daily Drops',
              style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12,),
            Column(
              children: dummySneakers.map((sneaker) {
                  return Container(
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                      color: isDarkMode ? Colors.grey[850] : Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: isDarkMode? Colors.black54 : Colors.grey.withOpacity(0.2),
                          blurRadius: 6,
                          offset: Offset(0,3),
                        ),
                      ],
                    ),
                    child: ListTile(
                      leading: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.network(sneaker.imageUrl,width: 50,),

                      ),
                      title: Text(
                        sneaker.name,
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: const Text("Coming soon 🔥"),
                        trailing: const Icon(Icons.arrow_forward_ios,size: 14,),
                      ),
                    );
              }).toList(),
            ),
            const SizedBox(height: 30,),
          ],
      ),
      ),
      );
  }

}